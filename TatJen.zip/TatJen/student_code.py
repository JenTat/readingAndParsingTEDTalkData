import csv
from datetime import datetime

def date_converter(timestamp):
    
    date = datetime.utcfromtimestamp(timestamp).strftime('%Y-%m-%d')
    return date 

def minutes(time):

    minutes = int(time)//60
    return minutes                   

def get_video(filename):

    ted_dict = {}
    
    with open(filename, encoding='utf-8', errors='ignore') as fileIn:
    
        reader = csv.DictReader(fileIn)

        for line in reader:

            ted_list = ["", "", [], "", None, "", ""]
            title = line["fulltitle"].split(': ')[-1]
            video = line["webpage_url"]
            ted_list[-1] = video
            if title not in ted_dict:
                ted_dict[title] = ted_list

        return ted_dict

def get_transcript(filename, ted_dict):
  
    with open(filename, encoding='utf-8', errors='ignore') as fileIn:
    
        reader = csv.DictReader(fileIn)

        for line in reader:
            
            title = line["title"]
            url = line["url"]

            if title in ted_dict:
                ted_dict[title][-2] = url
        return ted_dict

def get_tags(filename, ted_dict):
    
    with open(filename, encoding='utf-8', errors='ignore') as fileIn:
    
        reader = csv.DictReader(fileIn)

        for line in reader:
            
            t = line["tags"].split(",")
            title = line["title"]

            if title in ted_dict:
                ted_dict[title][2] = t

        return ted_dict

def read_parse_ted_data(filename, ted_dict):
    
    tedTalk_dictionary = {}

    with open(filename, encoding='utf-8', errors='ignore') as fileIn:

        reader = csv.DictReader(fileIn)
        
        for line in reader:

            key = line['name'].split(': ')[-1]
            name = line["main_speaker"]
            date = date_converter(int(line["published_date"]))
            duration = minutes(line["duration"])
            description = line["description"]
            
            if key in ted_dict:
                ted_dict[key][0] = name
                ted_dict[key][1] = description
                ted_dict[key][3] = date
                ted_dict[key][4] = duration
                        
                if line["event"] not in tedTalk_dictionary:
                    tedTalk_dictionary[line["event"]] = {}
                tedTalk_dictionary[line["event"]][key] = ted_dict[key]
                    
        return tedTalk_dictionary

def print_tedTalk_info(ted_dictionary):
    
    print(f'{{')
    
    for event in ted_dictionary:
        
        print(f'{event}:')
        print(f'{{')
        
        for title in ted_dictionary[event]:
        
            print(f'{title}: ')
            print(f'{ted_dictionary[event][title]}')
            print(f',')
        print('},')
    
##        for t in ted_dictionary[key]:
##            print(f'{t}: \t {ted_dictionary[key][t]}')

##        for speaker in ted_dictionary[key]:
##            
##            print(f"{speaker}")
##            for detail in ted_dictionary[key][speaker]:
##                if type(detail) == int:
##                    print(f"- {detail} minutes")
##                else:
##                    print(f"- {detail}")

def main():
#After further inspection, the transcript file that belonged in
#the original data set provided by Rounak Banik does not
#corroborate with the "ted_main.csv" file, despite being created
#in the same data set. Thus, a different file was used from a different
#data set.

##    name = ""
##    des = ""
##    t = []
##    pd = ""
##    dur = None
##    trans = ""
##    vid = ""
    t_dict = get_video("tedYoutube.csv")
    w_trans = get_transcript("transcripts.csv", t_dict)
    w_tags =  get_tags("tedTags.csv", w_trans)
    tedTalk_dict = read_parse_ted_data("ted_main.csv", w_tags)
    print_tedTalk_info(tedTalk_dict)

main()


